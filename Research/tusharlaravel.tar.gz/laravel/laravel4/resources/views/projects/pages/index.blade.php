@extends('projects.layout.default')
@section('content')
    <h2>Projects</h2>
    @if( $projects->count() ===0)
        You have no projects
    @else
        <ul>
            @foreach( $projects as $project )
                <li><a href="{{ route('projects.show', $project->slug) }}">{{ $project->name }}</a></li>
            @endforeach
        </ul>
    @endif

 @endsection   