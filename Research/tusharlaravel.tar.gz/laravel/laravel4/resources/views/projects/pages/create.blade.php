@extends('projects.layout.default')
@section('content')
    i am the create page
@stop