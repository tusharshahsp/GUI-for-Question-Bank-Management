<?php

namespace App\Http\Controllers;


use App\Project;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class ProjectsController extends  Controller
{
    


  
    public function index(){

    	$projects = Project::all();
         return view('projects.pages.index', compact('projects'));
    }


    public function create(){ 
	  return view('projects.pages.create');
    }


    public function store()
	{
		//
	}

  


	
    
    public function show(Project $project)
   {
        return view('projects.pages.show', compact('project'));
   }


    public function edit(Project $project)
    {
    	return view('projects.pages.edit',compact('project'));
    }
    

    public function destroy(Project $project)
    {
    	//
    }
}
