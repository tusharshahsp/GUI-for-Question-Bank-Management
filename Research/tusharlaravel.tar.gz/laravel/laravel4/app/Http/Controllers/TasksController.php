<?php

namespace App\Http\Controllers;

use App\Task
use App\Http\Requests;
use App\Http\Controllers\Controller
use Illuminate\Http\Request;



class TasksController extends Controller
{
    //
    public function index(Project $project){
    	return view('tasks.pages.index', compact('project'));

    }


    public function create(Project $project){
    	return view('tasks.pages.create', compact('project'));

    }


    public function edit(Project $project){
    	return view('tasks.pages.edit', compact('project'));

    }


    public function update(Project $project ,Task $task){

    }


    public function show(Project $project, Task $task){
    	return view('tasks.pages.show', compact('project'));

    }


    public function destroy(Project $project , Task $task){

    }
}
