<?php $__env->startSection('content'); ?>
    i am the create page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('projects.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>