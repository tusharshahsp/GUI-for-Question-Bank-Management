<?php $__env->startSection('content'); ?>
    <h2><?php echo e($project->name); ?></h2>
    <?php if(  !$project->tasks->count()  ): ?>
       Your project has no tasks
    <?php else: ?>
     <ul>
     	<?php foreach( $project->tasks as $task ): ?>
     	<li><a href="<?php echo e(route( 'projects.tasks.show', [ $project->slug, $task->slug] )); ?> " > <?php echo e($task->name); ?></a></li>
     	<?php endforeach; ?>
     </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('projects.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>