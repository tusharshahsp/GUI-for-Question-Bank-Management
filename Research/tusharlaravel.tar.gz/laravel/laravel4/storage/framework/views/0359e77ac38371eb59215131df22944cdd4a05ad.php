<?php $__env->startSection('content'); ?>
    <h2>Projects</h2>
    <?php if( $projects->count() ===0): ?>
        You have no projects
    <?php else: ?>
        <ul>
            <?php foreach( $projects as $project ): ?>
                <li><a href="<?php echo e(route('projects.show', $project->slug)); ?>"><?php echo e($project->name); ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

 <?php $__env->stopSection(); ?>   
<?php echo $__env->make('projects.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>